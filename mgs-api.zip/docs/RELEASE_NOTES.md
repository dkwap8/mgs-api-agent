# Final Source Release Notes

## Release classification

Latest cumulative source package. The functional roadmap is frozen.

## Included

- Complete Laravel application source.
- Vue frontend source and Vite configuration.
- Database migrations and seeders.
- Multi-business wallet, API-key, settlement-account, transaction, payout, report, and dashboard scoping changes.
- KYC lifecycle, virtual-account provisioning, provider operations, webhook processing, idempotency, reconciliation, notification delivery, and administration modules.
- Central API response and verification modal contracts.
- Release, deployment, operations, environment, upgrade, rollback, UI/UX, and removal documentation.

## Pending Deployment Verification

Runtime verification was not executed in the packaging environment because Composer and npm dependencies could not be installed from their external registries. The deployment team must run all commands below successfully:

```bash
composer install --no-dev
composer dump-autoload -o
php artisan optimize:clear
php artisan optimize
php artisan migrate --force
php artisan test
npm ci
npm run build
php artisan queue:restart
php artisan schedule:list
```

After the commands pass, complete the following deployment verification:

1. Confirm all required queue workers are active for `payments`, `webhooks`, `providers`, `notifications`, `kyc`, and `default` as applicable.
2. Complete registration → merchant → business → KYC → virtual account → collection → wallet → transaction → payout → notification testing.
3. Create one merchant with at least two businesses and prove complete financial isolation.
4. Verify duplicate webhook handling, idempotency, retries, timeouts, reconciliation, failed payouts, and successful payouts.
5. Verify browser rendering and responsive behaviour using the matrix in `FINAL_FRONTEND_UI_UX_AUDIT.md`.

This package must not be labelled runtime-verified until the deployment checks above pass.
