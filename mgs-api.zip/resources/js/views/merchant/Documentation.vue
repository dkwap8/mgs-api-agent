<template>
    <div class="flex min-h-screen bg-slate-50 dark:bg-slate-900">
        <!-- Sidebar -->
        <aside class="fixed left-0 top-0 z-40 h-screen w-64 border-r border-slate-200 bg-white dark:border-slate-700 dark:bg-slate-950">
            <div class="flex h-full flex-col px-4 py-6">
                <!-- Logo -->
                <div class="mb-6 flex items-center gap-2">
                    <span class="text-2xl font-bold text-indigo-600 dark:text-indigo-500">PayDrex</span>
                </div>

                <!-- User Profile -->
                <div class="mb-6 rounded-2xl border border-slate-200 p-4 dark:border-slate-700">
                    <div class="flex items-center gap-3">
                        <div class="flex h-12 w-12 items-center justify-center rounded-full bg-indigo-600 text-white font-bold">
                            RA
                        </div>
                        <div>
                            <p class="font-semibold text-slate-950 dark:text-white">Rabiu Abubakar</p>
                            <p class="text-sm text-slate-500 dark:text-slate-400">Business Code: PGS000001</p>
                        </div>
                    </div>
                    <div class="mt-2 flex items-center gap-2">
                        <span class="inline-block h-2 w-2 rounded-full bg-green-500"></span>
                        <span class="text-xs text-green-600 dark:text-green-400">Active</span>
                    </div>
                </div>

                <!-- Navigation -->
                <nav class="flex-1 space-y-1 overflow-y-auto">
                    <p class="mb-2 text-xs font-semibold uppercase text-slate-400 dark:text-slate-500">Payouts</p>
                    <router-link to="/merchant/payouts" class="flex items-center gap-3 rounded-xl px-3 py-2 text-sm hover:bg-slate-100 dark:hover:bg-[#2a2a2a]">
                        📤 Payouts
                    </router-link>

                    <p class="mb-2 mt-4 text-xs font-semibold uppercase text-slate-400 dark:text-slate-500">Developer</p>
                    <router-link to="/merchant/api-keys" class="flex items-center gap-3 rounded-xl px-3 py-2 text-sm hover:bg-slate-100 dark:hover:bg-[#2a2a2a]">
                        🔑 API Keys
                    </router-link>
                    <router-link to="/merchant/webhooks" class="flex items-center gap-3 rounded-xl px-3 py-2 text-sm hover:bg-slate-100 dark:hover:bg-[#2a2a2a]">
                        🌐 Webhooks
                    </router-link>
                    <router-link to="/merchant/documentation" class="flex items-center gap-3 rounded-xl bg-indigo-50 px-3 py-2 text-sm text-indigo-600 dark:bg-[#1f2937] dark:text-indigo-400">
                        📚 Documentation
                    </router-link>

                    <p class="mb-2 mt-4 text-xs font-semibold uppercase text-slate-400 dark:text-slate-500">Account</p>
                    <router-link to="/merchant/settings" class="flex items-center gap-3 rounded-xl px-3 py-2 text-sm hover:bg-slate-100 dark:hover:bg-[#2a2a2a]">
                        ⚙️ Profile & Settings
                    </router-link>
                    <router-link to="/merchant/help" class="flex items-center gap-3 rounded-xl px-3 py-2 text-sm hover:bg-slate-100 dark:hover:bg-[#2a2a2a]">
                        ❓ Help & Support
                    </router-link>
                </nav>

                <!-- Logout -->
                <div class="border-t border-slate-200 pt-4 dark:border-slate-700">
                    <button class="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950">
                        🚪 Logout
                    </button>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <div class="ml-64 flex-1">
            <!-- Header -->
            <header class="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur dark:border-slate-700 dark:bg-slate-950/95">
                <div class="flex h-16 items-center justify-between px-6">
                    <h1 class="text-lg font-semibold text-slate-950 dark:text-white">Documentation</h1>
                    <div class="flex items-center gap-4">
                        <!-- Theme Toggle -->
                        <button @click="toggleTheme" class="rounded-xl p-2 hover:bg-slate-100 dark:hover:bg-[#2a2a2a]">
                            {{ isDark ? '☀️' : '🌙' }}
                        </button>
                    </div>
                </div>
            </header>

            <!-- Content -->
            <main class="p-6">
                <div class="max-w-4xl">
                    <h1 class="text-3xl font-bold text-slate-950 dark:text-white">Overview</h1>
                    <p class="mt-2 text-slate-600 dark:text-slate-300">
                        MGS API gives merchants a simple way to manage payment infrastructure.
                        MGS API helps developers integrate customer management, virtual accounts,
                        wallet balance, transactions, payouts, webhooks, and analytics into their
                        own applications.
                    </p>

                    <!-- Base URLs -->
                    <div class="mt-8 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-700 dark:bg-slate-950">
                        <h2 class="text-xl font-semibold text-slate-950 dark:text-white">Production Base URL</h2>
                        <div class="mt-2 rounded-xl bg-slate-100 p-3 font-mono text-sm dark:bg-slate-900">
                            https://mgs.com.ng/api/v1
                        </div>
                    </div>

                    <div class="mt-4 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-700 dark:bg-slate-950">
                        <h2 class="text-xl font-semibold text-slate-950 dark:text-white">Local Development URL</h2>
                        <div class="mt-2 rounded-xl bg-slate-100 p-3 font-mono text-sm dark:bg-slate-900">
                            http://127.0.0.1:8000/api/v1
                        </div>
                    </div>

                    <!-- Authentication -->
                    <div class="mt-8 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-700 dark:bg-slate-950">
                        <h2 class="text-xl font-semibold text-slate-950 dark:text-white">Authentication</h2>
                        <p class="mt-2 text-slate-600 dark:text-slate-300">
                            Authentication protected requests using your MGS secret key.
                            Send your secret key in the Authorization header as a Bearer token.
                            Never expose your secret key inside frontend JavaScript or public apps.
                        </p>

                        <div class="mt-4 rounded-xl bg-slate-100 p-4 dark:bg-slate-900">
                            <p class="font-mono text-sm text-slate-800 dark:text-gray-200">
                                Authorization: Bearer MGS_SK_xxxxxxxxxxxxxxxxxxxxxx
                            </p>
                            <p class="mt-1 font-mono text-sm text-slate-800 dark:text-gray-200">
                                Accept: application/json
                            </p>
                            <p class="mt-1 font-mono text-sm text-slate-800 dark:text-gray-200">
                                Content-Type: application/json
                            </p>
                        </div>

                        <div class="mt-4 rounded-xl bg-yellow-50 p-3 text-sm text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300">
                            ⚠️ Keep your secret key private. Public keys may be used on client-side flows only when supported.
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</template>

<script>
import { ref, onMounted } from 'vue';

export default {
    name: 'Documentation',

    setup() {
        const isDark = ref(false);

        const toggleTheme = () => {
            isDark.value = !isDark.value;
            if (isDark.value) {
                document.documentElement.classList.add('dark');
                localStorage.setItem('theme', 'dark');
            } else {
                document.documentElement.classList.remove('dark');
                localStorage.setItem('theme', 'light');
            }
        };

        onMounted(() => {
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                isDark.value = true;
                document.documentElement.classList.add('dark');
            }
        });

        return {
            isDark,
            toggleTheme,
        };
    },
};
</script>