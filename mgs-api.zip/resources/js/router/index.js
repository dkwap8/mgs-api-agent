import {
    createRouter,
    createWebHistory,
} from 'vue-router';

const routes = [
    {
        path: '/login',
        component: () =>
            import('../views/Login.vue'),
        meta: {
            guest: true,
        },
    },

    {
        path: '/register',
        component: () =>
            import('../views/Register.vue'),
        meta: {
            guest: true,
        },
    },

    {
        path: '/forgot-password',
        component: () =>
            import('../views/ForgotPassword.vue'),
        meta: {
            guest: true,
        },
    },

    {
        path: '/reset-password',
        component: () =>
            import('../views/ResetPassword.vue'),
        meta: {
            guest: true,
        },
    },

    /*
    |--------------------------------------------------------------------------
    | Merchant Routes
    |--------------------------------------------------------------------------
    */

    {
        path: '/merchant',
        component: () =>
            import('../layouts/MerchantLayout.vue'),

        meta: {
            requiresMerchant: true,
        },

        children: [
            {
                path: '',
                component: () =>
                    import(
                        '../views/merchant/Dashboard.vue'
                    ),
                meta: {
                    title: 'Dashboard',
                },
            },

            {
                path: 'analytics',
                component: () =>
                    import(
                        '../views/merchant/Analytics.vue'
                    ),
                meta: {
                    title: 'Analytics',
                },
            },

            {
                path: 'customers',
                component: () =>
                    import(
                        '../views/merchant/Customers.vue'
                    ),
                meta: {
                    title: 'Customers',
                },
            },

            {
                path: 'accounts',
                component: () =>
                    import(
                        '../views/merchant/VirtualAccounts.vue'
                    ),
                meta: {
                    title: 'Virtual Accounts',
                },
            },

            {
                path: 'transactions',
                component: () =>
                    import(
                        '../views/merchant/Transactions.vue'
                    ),
                meta: {
                    title: 'Transactions',
                },
            },

            {
                path: 'wallet',
                component: () =>
                    import(
                        '../views/merchant/Wallet.vue'
                    ),
                meta: {
                    title: 'Wallet',
                },
            },

            {
                path: 'payouts',
                component: () =>
                    import(
                        '../views/merchant/Payouts.vue'
                    ),
                meta: {
                    title: 'Payouts',
                },
            },

            {
                path: 'api-keys',
                component: () =>
                    import(
                        '../views/merchant/ApiKeys.vue'
                    ),
                meta: {
                    title: 'API Keys',
                },
            },

            {
                path: 'webhooks',
                component: () =>
                    import(
                        '../views/merchant/Webhooks.vue'
                    ),
                meta: {
                    title: 'Webhooks',
                },
            },

            {
                path: 'documentation',
                component: () =>
                    import(
                        '../views/merchant/Documentation.vue'
                    ),
                meta: {
                    title: 'Documentation',
                },
            },

            {
                path: 'help',
                name: 'HelpSupport',
                component: () =>
                    import(
                        '../views/merchant/HelpSupport.vue'
                    ),
                meta: {
                    title: 'Help & Support',
                },
            },

            {
                path: 'settings',
                component: () =>
                    import(
                        '../views/merchant/Settings.vue'
                    ),
                meta: {
                    title: 'Settings',
                },
            },

            {
                path: 'activate',
                component: () =>
                    import(
                        '../views/merchant/ActivateBusiness.vue'
                    ),
                meta: {
                    title: 'Activate Business',
                },
            },
        ],
    },

    /*
    |--------------------------------------------------------------------------
    | Admin Routes
    |--------------------------------------------------------------------------
    */

    {
        path: '/admin',
        component: () =>
            import('../layouts/AdminLayout.vue'),

        meta: {
            requiresAdmin: true,
        },

        children: [
            {
                path: '',
                component: () =>
                    import(
                        '../views/admin/Dashboard.vue'
                    ),
                meta: {
                    title: 'Dashboard',
                },
            },

            {
                path: 'merchants',
                component: () =>
                    import(
                        '../views/admin/Merchants.vue'
                    ),
                meta: {
                    title: 'Merchants',
                },
            },

            {
                path: 'providers',
                component: () =>
                    import(
                        '../views/admin/Providers.vue'
                    ),
                meta: {
                    title: 'Providers',
                },
            },

            {
                path: 'transactions',
                component: () =>
                    import(
                        '../views/admin/Transactions.vue'
                    ),
                meta: {
                    title: 'Transactions',
                },
            },

            {
                path: 'payouts',
                component: () =>
                    import(
                        '../views/admin/Payouts.vue'
                    ),
                meta: {
                    title: 'Payouts',
                },
            },

            {
                path: 'reports',
                component: () =>
                    import(
                        '../views/admin/Reports.vue'
                    ),
                meta: {
                    title: 'Reports',
                },
            },

            {
                path: 'settings',
                component: () =>
                    import(
                        '../views/admin/Settings.vue'
                    ),
                meta: {
                    title: 'Settings',
                },
            },

            {
                path: 'notifications',
                name: 'AdminNotifications',
                component: () =>
                    import(
                        '../views/admin/Notifications.vue'
                    ),
                meta: {
                    title: 'Notifications',
                },
            },

            {
                path: 'support',
                component: () =>
                    import(
                        '../views/admin/SupportTickets.vue'
                    ),
                meta: {
                    title: 'Support Tickets',
                },
            },

            {
                path: 'customers',
                component: () =>
                    import(
                        '../views/admin/Customers.vue'
                    ),
                meta: {
                    title: 'Customers',
                },
            },

            {
                path: 'business-activations',
                name: 'AdminBusinessActivations',
                component: () =>
                    import(
                        '../views/admin/BusinessActivations.vue'
                    ),
                meta: {
                    title: 'Business Activations',
                },
            },

            {
                path: 'withdrawal-settings',
                component: () =>
                    import(
                        '../views/admin/WithdrawalSettings.vue'
                    ),
                meta: {
                    title: 'Withdrawal Settings',
                },
            },

            {
                path: 'activity-logs',
                component: () =>
                    import(
                        '../views/admin/ActivityLogs.vue'
                    ),
                meta: {
                    title: 'Activity Logs',
                },
            },
        ],
    },

    /*
    |--------------------------------------------------------------------------
    | Default Route
    |--------------------------------------------------------------------------
    */

    {
        path: '/',
        redirect: () => {
            const adminToken =
                localStorage.getItem('admin_token');

            const merchantToken =
                localStorage.getItem('merchant_token');

            if (adminToken) {
                return '/admin';
            }

            if (merchantToken) {
                return '/merchant';
            }

            return '/login';
        },
    },

    /*
    |--------------------------------------------------------------------------
    | Not Found
    |--------------------------------------------------------------------------
    */

    {
        path: '/:pathMatch(.*)*',
        redirect: () => {
            const adminToken =
                localStorage.getItem('admin_token');

            const merchantToken =
                localStorage.getItem('merchant_token');

            if (adminToken) {
                return '/admin';
            }

            if (merchantToken) {
                return '/merchant';
            }

            return '/login';
        },
    },
];

const router = createRouter({
    history: createWebHistory(),
    routes,
});

router.beforeEach((to, from, next) => {
    const adminToken =
        localStorage.getItem('admin_token');

    const merchantToken =
        localStorage.getItem('merchant_token');

    const requiresAdmin =
        to.matched.some(
            (record) =>
                record.meta.requiresAdmin
        );

    const requiresMerchant =
        to.matched.some(
            (record) =>
                record.meta.requiresMerchant
        );

    const isGuestRoute =
        to.matched.some(
            (record) =>
                record.meta.guest
        );

    /*
    |--------------------------------------------------------------------------
    | Protect Admin Routes
    |--------------------------------------------------------------------------
    */

    if (
        requiresAdmin &&
        !adminToken
    ) {
        return next({
            path: '/login',
            query: {
                type: 'admin',
            },
        });
    }

    /*
    |--------------------------------------------------------------------------
    | Protect Merchant Routes
    |--------------------------------------------------------------------------
    */

    if (
        requiresMerchant &&
        !merchantToken
    ) {
        return next('/login');
    }

    /*
    |--------------------------------------------------------------------------
    | Redirect Logged-In Users Away From Guest Pages
    |--------------------------------------------------------------------------
    */

    if (isGuestRoute) {
        if (adminToken) {
            return next('/admin');
        }

        if (merchantToken) {
            return next('/merchant');
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Page Title
    |--------------------------------------------------------------------------
    */

    document.title = to.meta.title
        ? `${to.meta.title} - MGS API`
        : 'MGS API';

    return next();
});

export default router;