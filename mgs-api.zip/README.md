# Multi-Business Fintech Platform

Integrated Laravel and Vue application for merchant onboarding, multi-business financial operations, KYC verification, virtual accounts, collections, wallets, transactions, payouts, notifications, provider operations, reporting, and administration.

## Release status

This source package contains the latest cumulative implementation. Source-level integration and static syntax checks were completed in the preparation environment.

**Pending Deployment Verification:** Composer and npm dependencies could not be installed in the preparation environment because external package registries were unavailable. The deployment team must run the commands in `docs/RELEASE_NOTES.md` and complete the runtime and end-to-end checks before treating the deployment as production verified.

## Important architecture

- Financial records are scoped to both merchant and business.
- Wallets are unique by merchant, business, and currency.
- API keys and settlement accounts are business-owned.
- The frontend sends the active business through `X-Business-ID` and clears business-scoped state on switching.
- Queued work is separated across payments, webhooks, providers, notifications, and KYC queues.
- API responses use a consistent request-ID and notification contract.

## Documentation

- `docs/RELEASE_NOTES.md`
- `docs/ENGINEERING_CHANGE_LOG.md`
- `docs/DEPLOYMENT_GUIDE.md`
- `docs/OPERATIONS_RUNBOOK.md`
- `docs/ENVIRONMENT_CONFIGURATION_GUIDE.md`
- `docs/UPGRADE_GUIDE.md`
- `docs/ROLLBACK_GUIDE.md`
- `docs/FINAL_FRONTEND_UI_UX_AUDIT.md`
- `docs/VERIFICATION_MODAL_SYSTEM.md`
- `REMOVED_FILES.txt`

## Source package policy

The archive intentionally excludes `.env`, `vendor/`, `node_modules/`, runtime logs, framework cache files, and test result caches. Use `.env.example` as the deployment template.
