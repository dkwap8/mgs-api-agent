<?php

namespace App\Services;

use App\Models\Provider;
use App\Models\ProviderFundingCharge;
use InvalidArgumentException;

class FundingChargeService
{
    public function calculate(
        Provider $provider,
        float|int|string $amount
    ): array {
        $amount = round((float) $amount, 2);

        if ($amount <= 0) {
            throw new InvalidArgumentException(
                'The funding amount must be greater than zero.'
            );
        }

        $provider->loadMissing('fundingCharge');

        $configuration = $provider->fundingCharge;

        if (
            ! $configuration ||
            ! $configuration->is_enabled
        ) {
            return [
                'provider_id' => $provider->id,
                'provider' => $provider->name,
                'amount' => $amount,
                'charge' => 0.0,
                'total_payable' => $amount,
                'wallet_credit' => $amount,
                'collection_mode' =>
                    ProviderFundingCharge::MODE_ADD_ON,
                'charge_type' => null,
                'charge_value' => 0,
                'maximum_charge' => null,
            ];
        }

        $charge = $configuration->calculate($amount);

        $addOn = $configuration->collection_mode ===
            ProviderFundingCharge::MODE_ADD_ON;

        return [
            'provider_id' => $provider->id,
            'provider' => $provider->name,
            'amount' => $amount,
            'charge' => $charge,

            'total_payable' => $addOn
                ? round($amount + $charge, 2)
                : $amount,

            'wallet_credit' => $addOn
                ? $amount
                : round(max($amount - $charge, 0), 2),

            'collection_mode' =>
                $configuration->collection_mode,

            'charge_type' =>
                $configuration->charge_type,

            'charge_value' =>
                $configuration->charge_type ===
                ProviderFundingCharge::TYPE_PERCENTAGE
                    ? (float) $configuration->percentage
                    : (float) $configuration->fixed_amount,

            'maximum_charge' =>
                $configuration->maximum_charge !== null
                    ? (float) $configuration->maximum_charge
                    : null,
        ];
    }
}