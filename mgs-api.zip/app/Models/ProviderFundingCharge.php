<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProviderFundingCharge extends Model
{
    public const TYPE_PERCENTAGE = 'percentage';
    public const TYPE_FIXED = 'fixed';

    public const MODE_ADD_ON = 'add_on';
    public const MODE_DEDUCT = 'deduct';

    protected $fillable = [
        'provider_id',
        'is_enabled',
        'charge_type',
        'percentage',
        'fixed_amount',
        'maximum_charge',
        'minimum_charge',
        'collection_mode',
        'metadata',
    ];

    protected $casts = [
        'is_enabled' => 'boolean',
        'percentage' => 'decimal:4',
        'fixed_amount' => 'decimal:2',
        'maximum_charge' => 'decimal:2',
        'minimum_charge' => 'decimal:2',
        'metadata' => 'array',
    ];

    public function provider(): BelongsTo
    {
        return $this->belongsTo(Provider::class);
    }

    public function calculate(float|int|string $amount): float
    {
        $amount = round((float) $amount, 2);

        if (! $this->is_enabled || $amount <= 0) {
            return 0.0;
        }

        $charge = match ($this->charge_type) {
            self::TYPE_PERCENTAGE =>
                $amount * ((float) $this->percentage / 100),

            self::TYPE_FIXED =>
                (float) $this->fixed_amount,

            default => 0,
        };

        if ($this->maximum_charge !== null) {
            $charge = min(
                $charge,
                (float) $this->maximum_charge
            );
        }

        if ($this->minimum_charge !== null) {
            $charge = max(
                $charge,
                (float) $this->minimum_charge
            );
        }

        return round(max($charge, 0), 2);
    }
}