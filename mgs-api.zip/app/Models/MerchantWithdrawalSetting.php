<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MerchantWithdrawalSetting extends Model
{
    public const TYPE_STARTER = 'starter';
    public const TYPE_REGISTERED = 'registered';

    public const CHARGE_PERCENTAGE = 'percentage';
    public const CHARGE_FIXED = 'fixed';

    public const FEE_MODE_DEDUCT = 'deduct';
    public const FEE_MODE_ADD_ON = 'add_on';

    protected $fillable = [
        'merchant_type',
        'withdrawals_enabled',
        'automatic_withdrawals_enabled',
        'automatic_withdrawal_limit',
        'minimum_withdrawal_amount',
        'maximum_withdrawal_amount',
        'daily_withdrawal_limit',
        'charge_enabled',
        'charge_type',
        'percentage',
        'fixed_amount',
        'maximum_charge',
        'minimum_charge',
        'fee_collection_mode',
        'daily_request_limit',
        'metadata',
    ];

    protected $casts = [
        'withdrawals_enabled' => 'boolean',
        'automatic_withdrawals_enabled' => 'boolean',
        'automatic_withdrawal_limit' => 'decimal:2',
        'minimum_withdrawal_amount' => 'decimal:2',
        'maximum_withdrawal_amount' => 'decimal:2',
        'daily_withdrawal_limit' => 'decimal:2',
        'charge_enabled' => 'boolean',
        'percentage' => 'decimal:4',
        'fixed_amount' => 'decimal:2',
        'maximum_charge' => 'decimal:2',
        'minimum_charge' => 'decimal:2',
        'daily_request_limit' => 'integer',
        'metadata' => 'array',
    ];

    public function calculateFee(
        float|int|string $amount
    ): float {
        $amount = round((float) $amount, 2);

        if (! $this->charge_enabled || $amount <= 0) {
            return 0.0;
        }

        $fee = match ($this->charge_type) {
            self::CHARGE_PERCENTAGE =>
                $amount * ((float) $this->percentage / 100),

            self::CHARGE_FIXED =>
                (float) $this->fixed_amount,

            default => 0,
        };

        if ($this->maximum_charge !== null) {
            $fee = min(
                $fee,
                (float) $this->maximum_charge
            );
        }

        if ($this->minimum_charge !== null) {
            $fee = max(
                $fee,
                (float) $this->minimum_charge
            );
        }

        return round(max($fee, 0), 2);
    }

    public function requiresManualReview(
        float|int|string $amount
    ): bool {
        $amount = (float) $amount;

        if (! $this->automatic_withdrawals_enabled) {
            return true;
        }

        if (
            (float) $this->automatic_withdrawal_limit <= 0
        ) {
            return true;
        }

        return $amount >
            (float) $this->automatic_withdrawal_limit;
    }
}