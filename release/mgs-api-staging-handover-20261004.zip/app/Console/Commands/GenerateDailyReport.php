<?php

namespace App\Console\Commands;

use Illuminate\Console\Attributes\Description;
use Illuminate\Console\Attributes\Signature;
use Illuminate\Console\Command;

#[Signature('app:generate-daily-report')]
#[Description('Command description')]
class GenerateDailyReport extends Command
{
    /**
     * Execute the console command.
     */
    public function handle()
    {
        //
    }
}
