<?php

namespace App\Services;

use App\Models\Business;
use App\Models\Merchant;
use App\Models\Payout;
use App\Models\Transaction;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;

class PlatformReportService
{
    public function build(string $period, ?string $customStart = null, ?string $customEnd = null): array
    {
        [$startDate, $endDate] = $this->resolvePeriod($period, $customStart, $customEnd);

        $transactions = $this->dateRange(Transaction::query(), $startDate, $endDate);
        $payouts = $this->dateRange(Payout::query(), $startDate, $endDate);
        $merchants = $this->dateRange(Merchant::query(), $startDate, $endDate);
        $businesses = $this->dateRange(Business::query(), $startDate, $endDate);

        $totalTransactions = (clone $transactions)->count();
        $successfulTransactions = (clone $transactions)->successful()->count();
        $pendingTransactions = (clone $transactions)->pending()->count();
        $failedTransactions = (clone $transactions)->failed()->count();
        $totalVolume = (float) (clone $transactions)->successful()->sum('amount');
        $totalFees = (float) (clone $transactions)->successful()->sum('fee');
        $totalMerchantAmount = (float) (clone $transactions)->successful()->sum('merchant_amount');
        $totalProfit = round($totalFees, 2);

        return [
            'period' => [
                'key' => $period,
                'start_date' => $startDate?->toDateString(),
                'end_date' => $endDate?->toDateString(),
            ],
            'overview' => [
                'total_merchants' => (clone $merchants)->count(),
                'total_businesses' => (clone $businesses)->count(),
                'approved_businesses' => (clone $businesses)->where('verification_status', Business::STATUS_APPROVED)->count(),
                'pending_businesses' => (clone $businesses)->whereIn('verification_status', [Business::STATUS_PENDING, Business::STATUS_UNDER_REVIEW])->count(),
                'suspended_businesses' => (clone $businesses)->where('verification_status', Business::STATUS_SUSPENDED)->count(),
                'total_transactions' => $totalTransactions,
                'successful_transactions' => $successfulTransactions,
                'pending_transactions' => $pendingTransactions,
                'failed_transactions' => $failedTransactions,
                'success_rate' => $totalTransactions > 0 ? round(($successfulTransactions / $totalTransactions) * 100, 2) : 0.0,
                'average_transaction' => $successfulTransactions > 0 ? round($totalVolume / $successfulTransactions, 2) : 0.0,
                'total_volume' => round($totalVolume, 2),
                'total_fees' => round($totalFees, 2),
                'merchant_settlement_value' => round($totalMerchantAmount, 2),
                'total_profit' => $totalProfit,
                'total_payout_value' => round((float) (clone $payouts)->sum('amount'), 2),
                'successful_payout_value' => round((float) (clone $payouts)->whereIn('status', Payout::SUCCESSFUL_STATUSES)->sum('amount'), 2),
                'pending_payout_value' => round((float) (clone $payouts)->whereIn('status', Payout::PENDING_STATUSES)->sum('amount'), 2),
            ],
            'transaction_types' => $this->transactionBreakdown('type', $startDate, $endDate),
            'transaction_statuses' => $this->transactionBreakdown('status', $startDate, $endDate),
            'daily_trend' => $this->dailyTrend($startDate, $endDate, $period),
            'top_businesses' => $this->topBusinesses($startDate, $endDate),
            'recent_activity' => $this->recentActivity($startDate, $endDate),
        ];
    }

    public function resolvePeriod(string $period, ?string $customStart = null, ?string $customEnd = null): array
    {
        $now = now();

        return match ($period) {
            'today' => [$now->copy()->startOfDay(), $now->copy()->endOfDay()],
            'yesterday' => [$now->copy()->subDay()->startOfDay(), $now->copy()->subDay()->endOfDay()],
            '7days' => [$now->copy()->subDays(6)->startOfDay(), $now->copy()->endOfDay()],
            '30days' => [$now->copy()->subDays(29)->startOfDay(), $now->copy()->endOfDay()],
            'month' => [$now->copy()->startOfMonth(), $now->copy()->endOfMonth()],
            'year' => [$now->copy()->startOfYear(), $now->copy()->endOfYear()],
            'custom' => [Carbon::parse($customStart)->startOfDay(), Carbon::parse($customEnd)->endOfDay()],
            'all' => [null, null],
            default => [$now->copy()->subDays(29)->startOfDay(), $now->copy()->endOfDay()],
        };
    }

    private function dateRange(Builder $query, ?Carbon $startDate, ?Carbon $endDate): Builder
    {
        return $query
            ->when($startDate, fn (Builder $builder) => $builder->where('created_at', '>=', $startDate))
            ->when($endDate, fn (Builder $builder) => $builder->where('created_at', '<=', $endDate));
    }

    private function transactionBreakdown(string $column, ?Carbon $startDate, ?Carbon $endDate): array
    {
        return $this->dateRange(
            Transaction::query()
                ->select([$column, DB::raw('COUNT(*) as total'), DB::raw('COALESCE(SUM(amount), 0) as amount')])
                ->groupBy($column)
                ->orderByDesc('amount'),
            $startDate,
            $endDate
        )->get()->map(fn (Transaction $item) => [
            $column => $item->{$column} ?: 'unknown',
            'total' => (int) $item->total,
            'amount' => (float) $item->amount,
        ])->values()->all();
    }

    private function dailyTrend(?Carbon $startDate, ?Carbon $endDate, string $period): array
    {
        $query = $this->dateRange(
            Transaction::query()
                ->select([
                    DB::raw('DATE(created_at) as report_date'),
                    DB::raw('COUNT(*) as total'),
                    DB::raw('COALESCE(SUM(amount), 0) as amount'),
                    DB::raw("SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successful"),
                ])
                ->groupBy(DB::raw('DATE(created_at)'))
                ->orderBy('report_date'),
            $startDate,
            $endDate
        );

        if ($period === 'all') {
            $query->limit(365);
        }

        return $query->get()->map(fn (Transaction $item) => [
            'date' => $item->report_date,
            'total' => (int) $item->total,
            'successful' => (int) $item->successful,
            'amount' => (float) $item->amount,
        ])->values()->all();
    }

    private function topBusinesses(?Carbon $startDate, ?Carbon $endDate): array
    {
        return $this->dateRange(
            Transaction::query()
                ->select([
                    'business_id',
                    DB::raw('COUNT(*) as total_transactions'),
                    DB::raw('COALESCE(SUM(amount), 0) as total_volume'),
                    DB::raw('COALESCE(SUM(fee), 0) as total_fees'),
                ])
                ->whereNotNull('business_id')
                ->successful()
                ->with('business.merchant.user')
                ->groupBy('business_id')
                ->orderByDesc('total_volume')
                ->limit(10),
            $startDate,
            $endDate
        )->get()->map(fn (Transaction $item) => [
            'business_id' => $item->business_id,
            'business_name' => $item->business?->name ?: 'Unnamed Business',
            'merchant_id' => $item->business?->merchant_id,
            'owner_name' => $item->business?->merchant?->user?->name,
            'total_transactions' => (int) $item->total_transactions,
            'total_volume' => (float) $item->total_volume,
            'total_fees' => (float) $item->total_fees,
        ])->values()->all();
    }

    private function recentActivity(?Carbon $startDate, ?Carbon $endDate): array
    {
        return $this->dateRange(
            Transaction::query()->with(['business:id,name,merchant_id', 'merchant.user:id,name,email', 'customer:id,first_name,last_name,email']),
            $startDate,
            $endDate
        )->latest('id')->limit(10)->get()->toArray();
    }
}
