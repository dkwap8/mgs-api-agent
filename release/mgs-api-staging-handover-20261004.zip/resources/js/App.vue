<template>
    <div id="app">
        <router-view />
        <VerificationModal />
        <notifications position="top right" />
    </div>
</template>

<script>
import VerificationModal from './components/VerificationModal.vue';

export default {
    name: 'App',
    components: { VerificationModal },
    mounted() {
        // Check authentication
        const token = localStorage.getItem('token');
        if (token) {
            // Set axios default header
            window.axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
        }
    }
};
</script>

<style>
#app {
    min-height: 100vh;
}
</style>