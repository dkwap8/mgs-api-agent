<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('business_activations', function (Blueprint $table) {
            $table->string('first_name', 100)
                ->nullable()
                ->after('business_name');

            $table->string('last_name', 100)
                ->nullable()
                ->after('first_name');

            $table->string('middle_name', 100)
                ->nullable()
                ->after('last_name');
        });
    }

    public function down(): void
    {
        Schema::table('business_activations', function (Blueprint $table) {
            $table->dropColumn([
                'first_name',
                'last_name',
                'middle_name',
            ]);
        });
    }
};