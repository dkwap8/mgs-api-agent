<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('business_activations', function (Blueprint $table) {
            $table->string('website_url', 2048)->nullable()->after('business_phone');
        });
    }

    public function down(): void
    {
        Schema::table('business_activations', function (Blueprint $table) {
            $table->dropColumn('website_url');
        });
    }
};
