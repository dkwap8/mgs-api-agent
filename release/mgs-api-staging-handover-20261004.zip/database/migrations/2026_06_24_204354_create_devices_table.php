<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('devices', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('device_id');
            $table->string('device_name')->nullable();
            $table->string('ip_address')->nullable();
            $table->string('platform')->nullable();
            $table->boolean('trusted')->default(false);
            $table->timestamp('last_seen_at')->nullable();
            $table->timestamps();
            
            $table->index(['user_id', 'device_id']);
        });
    }

    public function down(): void {
        Schema::dropIfExists('devices');
    }
};